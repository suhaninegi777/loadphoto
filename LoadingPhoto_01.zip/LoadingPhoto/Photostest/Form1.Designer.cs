﻿namespace Photostest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.addToolStripbtn = new System.Windows.Forms.ToolStrip();
            this.addToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.imageListView1 = new Manina.Windows.Forms.ImageListView();
            this.Movebtn = new Infragistics.Win.Misc.UltraButton();
            this.btnDestinationFolder = new Infragistics.Win.Misc.UltraButton();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.TotalSelectImg = new Infragistics.Win.Misc.UltraLabel();
            this.ultraProgressBar1 = new Infragistics.Win.UltraWinProgressBar.UltraProgressBar();
            this.ultraPanel1 = new Infragistics.Win.Misc.UltraPanel();
            this.File_send_counter = new Infragistics.Win.Misc.UltraLabel();
            this.addToolStripbtn.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.ultraPanel1.ClientArea.SuspendLayout();
            this.ultraPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // addToolStripbtn
            // 
            this.addToolStripbtn.Dock = System.Windows.Forms.DockStyle.None;
            this.addToolStripbtn.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.addToolStripbtn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripButton});
            this.addToolStripbtn.Location = new System.Drawing.Point(0, 0);
            this.addToolStripbtn.Name = "addToolStripbtn";
            this.addToolStripbtn.Size = new System.Drawing.Size(26, 25);
            this.addToolStripbtn.TabIndex = 1;
            this.addToolStripbtn.Text = "toolStrip1";
            // 
            // addToolStripButton
            // 
            this.addToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.addToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("addToolStripButton.Image")));
            this.addToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.addToolStripButton.Name = "addToolStripButton";
            this.addToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.addToolStripButton.Text = "Add Files..";
            this.addToolStripButton.ToolTipText = "Add Files..\r\n";
            this.addToolStripButton.Click += new System.EventHandler(this.addToolStripButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.152585F));
            this.tableLayoutPanel1.Controls.Add(this.addToolStripbtn, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 33);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // imageListView1
            // 
            this.imageListView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.imageListView1.Location = new System.Drawing.Point(0, 33);
            this.imageListView1.Name = "imageListView1";
            this.imageListView1.PersistentCacheDirectory = "";
            this.imageListView1.PersistentCacheSize = ((long)(100));
            this.imageListView1.Size = new System.Drawing.Size(800, 417);
            this.imageListView1.TabIndex = 3;
            this.imageListView1.UseWIC = true;
            // 
            // Movebtn
            // 
            this.Movebtn.Location = new System.Drawing.Point(166, 3);
            this.Movebtn.Name = "Movebtn";
            this.Movebtn.Size = new System.Drawing.Size(75, 23);
            this.Movebtn.TabIndex = 4;
            this.Movebtn.Text = "Movebtn";
            this.Movebtn.Click += new System.EventHandler(this.Movebtn_Click_1);
            // 
            // btnDestinationFolder
            // 
            this.btnDestinationFolder.Location = new System.Drawing.Point(3, 3);
            this.btnDestinationFolder.Name = "btnDestinationFolder";
            this.btnDestinationFolder.Size = new System.Drawing.Size(142, 23);
            this.btnDestinationFolder.TabIndex = 6;
            this.btnDestinationFolder.Text = "Select destination folder";
            this.btnDestinationFolder.Click += new System.EventHandler(this.btnDestinationFolder_Click);
            // 
            // ultraLabel1
            // 
            this.ultraLabel1.Location = new System.Drawing.Point(247, 10);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(121, 16);
            this.ultraLabel1.TabIndex = 8;
            this.ultraLabel1.Text = "Total selected images";
            // 
            // TotalSelectImg
            // 
            this.TotalSelectImg.Location = new System.Drawing.Point(374, 11);
            this.TotalSelectImg.Name = "TotalSelectImg";
            this.TotalSelectImg.Size = new System.Drawing.Size(52, 15);
            this.TotalSelectImg.TabIndex = 9;
            this.TotalSelectImg.Text = "0";
            // 
            // ultraProgressBar1
            // 
            this.ultraProgressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ultraProgressBar1.Location = new System.Drawing.Point(0, 29);
            this.ultraProgressBar1.Name = "ultraProgressBar1";
            this.ultraProgressBar1.Size = new System.Drawing.Size(794, 23);
            this.ultraProgressBar1.TabIndex = 10;
            this.ultraProgressBar1.Text = "[Formatted]";
            // 
            // ultraPanel1
            // 
            // 
            // ultraPanel1.ClientArea
            // 
            this.ultraPanel1.ClientArea.Controls.Add(this.File_send_counter);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraProgressBar1);
            this.ultraPanel1.ClientArea.Controls.Add(this.TotalSelectImg);
            this.ultraPanel1.ClientArea.Controls.Add(this.btnDestinationFolder);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraLabel1);
            this.ultraPanel1.ClientArea.Controls.Add(this.Movebtn);
            this.ultraPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ultraPanel1.Location = new System.Drawing.Point(0, 393);
            this.ultraPanel1.Name = "ultraPanel1";
            this.ultraPanel1.Size = new System.Drawing.Size(800, 57);
            this.ultraPanel1.TabIndex = 11;
            // 
            // File_send_counter
            // 
            this.File_send_counter.Location = new System.Drawing.Point(595, 9);
            this.File_send_counter.Name = "File_send_counter";
            this.File_send_counter.Size = new System.Drawing.Size(199, 13);
            this.File_send_counter.TabIndex = 12;
            this.File_send_counter.Text = "ultraLabel3";
            this.File_send_counter.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ultraPanel1);
            this.Controls.Add(this.imageListView1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.addToolStripbtn.ResumeLayout(false);
            this.addToolStripbtn.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ultraPanel1.ClientArea.ResumeLayout(false);
            this.ultraPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStrip addToolStripbtn;
        private System.Windows.Forms.ToolStripButton addToolStripButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Manina.Windows.Forms.ImageListView imageListView1;
        private Infragistics.Win.Misc.UltraButton Movebtn;
        private Infragistics.Win.Misc.UltraButton btnDestinationFolder;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.Misc.UltraLabel TotalSelectImg;
        private Infragistics.Win.UltraWinProgressBar.UltraProgressBar ultraProgressBar1;
        private Infragistics.Win.Misc.UltraPanel ultraPanel1;
        private Infragistics.Win.Misc.UltraLabel File_send_counter;
    }
}

