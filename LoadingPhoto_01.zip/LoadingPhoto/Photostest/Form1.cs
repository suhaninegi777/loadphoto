﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Photostest
{
    public partial class Form1 : Form
    {
        string destinationDirectory;
        public Form1()
        {
            InitializeComponent();
        }
        private void addToolStripButton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog() { Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp;*.gif" })
            {
                openFileDialog1.Multiselect = true;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    imageListView1.Items.AddRange(openFileDialog1.FileNames);
                }
            }
        }
        private void btnDestinationFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                destinationDirectory = dialog.SelectedPath;
            }
        }
        static readonly SemaphoreSlim semaphore = new SemaphoreSlim(4); // 4 concurrent operations 
        private static List<string> logMessages = new List<string>();
        private static readonly object logLock = new object();
        private static async Task MoveFileAsync(string source, string destination)
        {
            DateTime start_time = DateTime.Now;
            using (FileStream sourceStream = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.None, 524288, true)) //524288= 512 MB buffer
            using (FileStream destinationStream = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.None, 524288, true))
            {
                await sourceStream.CopyToAsync(destinationStream);
            }
            File.Delete(source);
           // Collect log message
            lock (logLock)       
            {
                 logMessages.Add($"{DateTime.Now}: Moved {source} to {destination}");
            }
        }
        private static async Task WriteLogsAsync(string logFilePath)
        {
            await Task.Run(() =>
            {
                lock (logLock)
                {
                    if (logMessages.Count > 0)
                    {
                        File.AppendAllLines(logFilePath, logMessages);
                        logMessages.Clear(); 
                    }
                }
            });
        }
        private async void Movebtn_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (destinationDirectory != null)
                {
                    string sourceDirectory = @"E:\CATRAT_Software\TestPhotos\Sample_image";
                    string logFilePath = @"E:\CATRAT_Software\TestPhotos\logfolder\LogFiles.txt";
                    TotalSelectImg.Text = imageListView1.SelectedItems.Count.ToString();
                    List<Task> tasks = new List<Task>();
                    int processedItems = 0;
                    var progress = new Progress<int>(ReportProgress);
                    void ReportProgress(int percent)
                    {
                        ultraProgressBar1.Value = percent;
                        File_send_counter.Visible = true;
                        File_send_counter.Text = $"Images Sent : {processedItems}/{imageListView1.SelectedItems.Count}";
                    }
                    foreach (var item in imageListView1.SelectedItems)
                    {
                        string fileName = item.Text;
                        string source = Path.Combine(sourceDirectory, fileName);
                        string destination = Path.Combine(destinationDirectory, fileName);

                        tasks.Add(Task.Run(async () =>
                        {
                            await semaphore.WaitAsync();
                            try
                            {
                                await MoveFileAsync(source, destination);
                                processedItems++;
                                //int currentProcessedItems = Interlocked.Increment(ref processedItems);
                                int percentage = (int)((processedItems / (double)imageListView1.SelectedItems.Count) * 100);
                                ((IProgress<int>)progress).Report(percentage);
                            }
                            finally
                            {
                                semaphore.Release();
                            }
                        }));
                    }
                    await Task.WhenAll(tasks);
                    await WriteLogsAsync(logFilePath);
                    MessageBox.Show("Photos sent and logging completed.");
                    imageListView1.Refresh();
                }
                else
                {
                    MessageBox.Show("You must first choose Destination Directory");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

    







