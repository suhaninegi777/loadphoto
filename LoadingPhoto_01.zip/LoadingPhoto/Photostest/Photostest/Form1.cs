﻿using Manina.Windows.Forms;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Photostest
{
    public partial class Form1 : Form
    {
        private Size initialthumbnailsize = new Size(100, 100);

        public Form1()
        {
            InitializeComponent();
            imageListView1.ItemDoubleClick += doubleClickOnImg;
            imageListView1.ThumbnailSize = initialthumbnailsize;
            trackBar1.Minimum = -1;
            trackBar1.Maximum = 500;
            trackBar1.TickFrequency = 10;
            trackBar1.Value = 0;
        }

        private void doubleClickOnImg(object sender, ItemClickEventArgs e)
        {
            imageListView1.View = Manina.Windows.Forms.View.Gallery;
        }

        private void addToolStripButton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog() { Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp;*.gif" })
            {
                openFileDialog1.Multiselect = true;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    imageListView1.Items.AddRange(openFileDialog1.FileNames);
                }
            }
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            imageListView1.View = Manina.Windows.Forms.View.Thumbnails;
        }

        private void galleryToolStripButton_Click(object sender, EventArgs e)
        {
            imageListView1.View = Manina.Windows.Forms.View.Gallery;
        }

        private void removeAllToolStripbtn_Click(object sender, EventArgs e)
        {
            imageListView1.Items.Clear();
        }


        private void incSize_Clickbtn(object sender, EventArgs e)
        {
            imageListView1.ThumbnailSize = new Size(imageListView1.ThumbnailSize.Width + 20, imageListView1.ThumbnailSize.Height + 20);
        }

        //Decrease the thumbnails size
        private void decSize_Clickbtn(object sender, EventArgs e)
        {
            imageListView1.ThumbnailSize = new Size(imageListView1.ThumbnailSize.Width - 20, imageListView1.ThumbnailSize.Height - 20);
        }

        int fixedValue = 5;
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            int newwidth = initialthumbnailsize.Width + trackBar1.Value;
            int newheight = initialthumbnailsize.Height + trackBar1.Value;
            newwidth = Math.Max(newwidth, 10);
            newheight = Math.Max(newheight, 10);
            imageListView1.ThumbnailSize = new Size(newwidth, newheight);
        }
    }





}
